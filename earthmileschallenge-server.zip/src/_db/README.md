# Data Model
![Data model for Earth Miles Challenge](https://github.com/Earth-Miles-Challenge/Express-Server/blob/main/data/dbModel.png?raw=true)

This data model is for the initial version of the app with the commutes feature.
