module.exports = {
	origin: 'http://localhost:3000',
	credentials: true
}